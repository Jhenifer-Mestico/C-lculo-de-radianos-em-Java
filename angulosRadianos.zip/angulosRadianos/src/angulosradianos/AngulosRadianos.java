/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angulosradianos;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class AngulosRadianos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        double alfa, rad, alt;
        float xmetros;
        
        Scanner inputData = new Scanner(System.in);
        System.out.println("Digite   ângulo (graus) de inclinação alfa (número real):");
        alfa = inputData.nextDouble(); 
        
          System.out.println("Digite   a distância da plataforma (m):");
        xmetros = inputData.nextFloat(); 
        
        rad = (alfa / 180)* Math.PI;
        alt = Math.tan(rad)* xmetros;
        
        System.out.printf("O valor da altura em metros (m) %.2f m\n:" , alt);
    }
    
}
